return {
	localhost = false,
	num_players = 2
}