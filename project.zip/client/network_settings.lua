return {
	localhost = false,
	p2p = false,
	num_players = 2
}